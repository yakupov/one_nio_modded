package one.nio.buffers;

public interface BufferPool<T> {
	T getBuffer();
	void returnBuffer(T buffer);
}
