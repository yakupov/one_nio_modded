package one.nio.buffers;

public class ByteArrayBufferPool implements BufferPool<byte[]> {
	private final int bufferSize;

	public ByteArrayBufferPool(int bufferSize) {
		this.bufferSize = bufferSize;
	}
	
	public byte[] getBuffer() {
		return new byte[bufferSize];
	}

	public void returnBuffer(byte[] buffer) {
		// Do mothing
	}
}
