package one.nio.rpc;

import one.nio.buffers.DirectByteBufferPool;
import one.nio.net.Session;
import one.nio.net.Socket;
import one.nio.serial.BBDeserializeStream;
import one.nio.serial.BBSerializeStream;
import one.nio.serial.CalcSizeStream;
import one.nio.serial.DeserializeStream;
import one.nio.serial.SerializerNotFoundException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.io.IOException;
import java.net.SocketException;
import java.nio.ByteBuffer;

public class RpcSession extends Session {
    private static final Log log = LogFactory.getLog(RpcSession.class);

    private final RpcServer server;
    private byte[] buffer;
    private int bytesRead;
    private int requestSize;

    public RpcSession(Socket socket, RpcServer server) {
        super(socket);
        this.server = server;
        this.buffer = new byte[DirectByteBufferPool.BUFFER_SIZE];
    }

    @Override
    @SuppressWarnings("unchecked")
    protected void processRead(byte[] unusedBuffer) throws Exception {
        byte[] buffer = this.buffer;
        int bytesRead = this.bytesRead;
        int requestSize = this.requestSize;

        // Read 4-bytes header
        if (requestSize == 0) {
            bytesRead += socket.read(buffer, bytesRead, 4 - bytesRead);
            if (bytesRead < 4) {
                this.bytesRead = bytesRead;
                return;
            }
            bytesRead = 0;

            if (buffer[0] != 0) {
                throw new IOException("Invalid request or request too large");
            }

            requestSize = this.requestSize = (buffer[1] & 0xff) << 16 | (buffer[2] & 0xff) << 8 | (buffer[3] & 0xff);
            if (requestSize > buffer.length) {
                buffer = this.buffer = new byte[requestSize];
            }
        }

        // Read request
        bytesRead += socket.read(buffer, bytesRead, requestSize - bytesRead);
        if (bytesRead < requestSize) {
            this.bytesRead = bytesRead;
            return;
        }

        // Request is complete - deserialize it
        this.bytesRead = 0;
        this.requestSize = 0;

        final Object request;
        try {
            request = new DeserializeStream(buffer).readObject();
        } catch (SerializerNotFoundException e) {
            writeResponse(e);
            return;
        } finally {
            if (requestSize > DirectByteBufferPool.BUFFER_SIZE) {
                this.buffer = new byte[DirectByteBufferPool.BUFFER_SIZE];
            }
        }

        // Perform the invocation
        if (server.getWorkersUsed()) {
            server.asyncExecute(new AsyncRequest(request));
        } else {
            writeResponse(server.invoke(request));
        }
    }
    
    @Override
    protected void processRead(ByteBuffer argBuffer) throws Exception {    	
        ByteBuffer buffer; //= this.bbuffer;
        if (argBuffer != null) {
        	buffer = argBuffer;
        	buffer.clear();
        } else {
	        try {
	        	buffer = DirectByteBufferPool.leaseBuffer();
	        } catch (Exception e) {
	        	e.printStackTrace();
	        	System.err.println ("RpcSession: Can't get DBB. Allocationg on-heap buffer");
	        	buffer = ByteBuffer.allocate(DirectByteBufferPool.BUFFER_SIZE);
	        }
        }
        
        int bytesRead = this.bytesRead;
        int requestSize = this.requestSize;
        
        // Read 4-bytes header
        if (requestSize == 0) {
        	ByteBuffer sbuf = ByteBuffer.allocate(4);
            bytesRead += socket.read(sbuf);
            if (bytesRead < 4) {
                this.bytesRead = bytesRead;
                return;
            }
            bytesRead = 0;

            if (sbuf.get(0) != 0) {
                throw new IOException("Invalid request or request too large");
            }

            requestSize = this.requestSize = (sbuf.get(1) & 0xff) << 16 | (sbuf.get(2) & 0xff) << 8 | (sbuf.get(3) & 0xff);
            if (requestSize > buffer.capacity()) {
            	if (buffer.isDirect())
            		DirectByteBufferPool.returnBuffer(buffer);
                buffer = ByteBuffer.allocate(requestSize);
            }
        }

        // Read request
        bytesRead += socket.read(buffer);
        if (bytesRead < requestSize) {
            this.bytesRead = bytesRead;
            return;
        }

        // Request is complete - deserialize it
        this.bytesRead = 0;
        this.requestSize = 0;

        final Object request;
        try {
            request = new BBDeserializeStream(buffer).readObject();
        } catch (SerializerNotFoundException e) {
            writeResponse(e);
            return;
        } finally {
            if (requestSize > DirectByteBufferPool.BUFFER_SIZE) {
                this.buffer = new byte[DirectByteBufferPool.BUFFER_SIZE];
            }
        }
        
        // Perform the invocation
        if (server.getWorkersUsed()) {
            server.asyncExecute(new AsyncRequest(request));
        } else {
            writeResponse(server.invoke(request));
        }
        
        if (buffer.isDirect() && buffer != argBuffer) {
    		DirectByteBufferPool.returnBuffer(buffer);
        }
    }
    	

    protected void writeResponse(Object response) throws IOException {
        CalcSizeStream calcSizeStream = new CalcSizeStream();
        calcSizeStream.writeObject(response);
        int size = calcSizeStream.count();
        calcSizeStream.close();
        
        //byte[] buffer = new byte[size + 4];
        ByteBuffer buffer;
        if (size + 4 < DirectByteBufferPool.BUFFER_SIZE) {
            try {
            	buffer = DirectByteBufferPool.leaseBuffer();
            } catch (Exception e) {
            	e.printStackTrace();
            	System.err.println ("RpcSession: Can't get DBB. Allocationg on-heap buffer");
            	buffer = ByteBuffer.allocate(DirectByteBufferPool.BUFFER_SIZE);
            }
        } else {
        	buffer = ByteBuffer.allocate(size + 4);
        }
        
        BBSerializeStream ss = new BBSerializeStream(buffer);
        ss.writeInt(size);
        ss.writeObject(response);
        ss.close();
        
        buffer.flip();
        super.write(buffer, 0, size + 4, false);
        
        if (buffer.isDirect()) {
			DirectByteBufferPool.returnBuffer(buffer);
        }
    }

    private class AsyncRequest implements Runnable {
        private final Object request;

        AsyncRequest(Object request) {
            this.request = request;
        }

        @Override
        @SuppressWarnings("unchecked")
        public void run() {
            try {
                writeResponse(server.invoke(request));
            } catch (SocketException e) {
                if (server.isRunning() && log.isDebugEnabled()) {
                    log.debug("Connection closed: " + clientIp());
                }
                close();
            } catch (Throwable e) {
                if (server.isRunning()) {
                    log.error("Cannot process session from " + clientIp(), e);
                }
                close();
            }
        }
    }
}
