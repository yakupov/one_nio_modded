package one.nio.rpc;

import one.nio.buffers.DirectByteBufferPool;
import one.nio.net.ConnectionString;
import one.nio.net.Socket;
import one.nio.pool.PoolException;
import one.nio.pool.SocketPool;
import one.nio.serial.BBDeserializeStream;
import one.nio.serial.BBSerializeStream;
import one.nio.serial.CalcSizeStream;
import one.nio.serial.DeserializeStream;
import one.nio.serial.Repository;
import one.nio.serial.SerializeStream;
import one.nio.serial.Serializer;
import one.nio.serial.SerializerNotFoundException;
import one.nio.util.JavaInternals;

import java.io.IOException;
import java.io.ObjectOutput;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.net.SocketException;
import java.nio.ByteBuffer;

public class RpcClient implements RpcService, InvocationHandler {
	public static final Method provideSerializerMethod =
			JavaInternals.getMethod(Repository.class, "provideSerializer", Serializer.class);
	public static final Method requestSerializerMethod =
			JavaInternals.getMethod(Repository.class, "requestSerializer", long.class);
	public static final int INT_SIZE = 4;

	private final SocketPool socketPool;


	public RpcClient(ConnectionString conn) throws IOException {
		socketPool = new SocketPool(conn);
	}

	/*
    @Override
    public Object invoke(Object request) throws Exception {
        byte[] buffer = invokeRaw(request);

        for (;;) {
            Object response;
            try {
                response = new DeserializeStream(buffer).readObject();
            } catch (SerializerNotFoundException e) {
                requestSerializer(e.getUid());
                continue;
            }

            if (!(response instanceof Exception)) {
                return response;
            } else if (response instanceof SerializerNotFoundException) {
                provideSerializer(((SerializerNotFoundException) response).getUid());
                buffer = invokeRaw(request);
            } else {
                throw (Exception) response;
            }
        }
    }
	 */  

	@Override
	public Object invoke(Object request) throws Exception {
		while (true) {
			Object response = bbInvokeRaw(request);
			if (response instanceof SerializerNotFoundException) {
				provideSerializer(((SerializerNotFoundException) response).getUid());
			} else if (response instanceof Exception) {
				throw (Exception) response;
			} else {
				return response;
			}
		}
		//    	ByteBuffer buffer = bbInvokeRaw(request);
		//    	
		//        while (true) {
		//            Object response;
		//            try {
		//                response = new BBDeserializeStream(buffer).readObject();
		//            } catch (SerializerNotFoundException e) {
		//                requestSerializer(e.getUid());
		//                continue;
		//            }
		//
		////            try {
		//				DirectByteBufferPool.returnBuffer(buffer);
		////			} catch (InvalidBufferException e) {
		////				e.printStackTrace();
		////			}
		//            
		//            if (!(response instanceof Exception)) {
		//                return response;
		//            } else if (response instanceof SerializerNotFoundException) {
		//                provideSerializer(((SerializerNotFoundException) response).getUid());
		//                buffer = bbInvokeRaw(request);
		//            } else {
		//                throw (Exception) response;
		//            }
		//        }
	}     

	private Object bbInvokeRaw(Object request) throws Exception {
		while (true) {
			final ByteBuffer pooledBuffer = DirectByteBufferPool.leaseBuffer();
			try {
				ByteBuffer requestBuffer = bbSerialize(request, pooledBuffer);
				Socket socket = socketPool.borrowObject();
				try {
					try {
						sendRequest(socket, requestBuffer);
					} catch (SocketException e) {
						// Stale connection? Retry on a fresh socket
						socketPool.destroyObject(socket);
						socket = socketPool.createObject();
						sendRequest(socket, requestBuffer);
					}

					try {
						ByteBuffer responseBuffer = readResponse(socket, pooledBuffer);
						socketPool.returnObject(socket);
						return new BBDeserializeStream(responseBuffer).readObject();
					} catch (SerializerNotFoundException e) {
						requestSerializer(e.getUid());
					}
				} catch (Exception e) {
					socketPool.invalidateObject(socket);
					throw e;
				}			
			} finally {
				DirectByteBufferPool.returnBuffer(pooledBuffer);
			}
		}
	}


	private byte[] invokeRaw(Object request) throws Exception {
		byte[] buffer = serialize(request);

		Socket socket = socketPool.borrowObject();
		try {
			try {
				sendRequest(socket, buffer);
			} catch (SocketException e) {
				// Stale connection? Retry on a fresh socket
				socketPool.destroyObject(socket);
				socket = socketPool.createObject();
				sendRequest(socket, buffer);
			}

			buffer = readResponse(socket, buffer);
			socketPool.returnObject(socket);
			return buffer;
		} catch (Exception e) {
			socketPool.invalidateObject(socket);
			throw e;
		}
	}

	//	private Object readResponse2(Socket socket, final ByteBuffer pooledBuffer)
	//			throws IOException, ClassNotFoundException {
	//	}
	//
	@Override
	public Object invoke(Object proxy, Method m, Object... args) throws Exception {
		return invoke(getInvocationObject(m, args));
	}

	protected Object getInvocationObject(Method m, Object... args) throws Exception {
		return new RemoteMethodCall(m, args);
	}

	protected void provideSerializer(long uid) throws Exception {
		Serializer serializer = Repository.requestSerializer(uid);
		Object remoteMethodCall = getInvocationObject(provideSerializerMethod, serializer);
		invokeRaw(remoteMethodCall);
	}

	protected void requestSerializer(long uid) throws Exception {
		Object remoteMethodCall = getInvocationObject(requestSerializerMethod, uid);
		byte[] response = invokeRaw(remoteMethodCall);
		Serializer serializer = (Serializer) new DeserializeStream(response).readObject();
		Repository.provideSerializer(serializer);
	}

	private byte[] serialize(Object request) throws IOException {
		int requestSize = calculateSize(request);

		byte[] buffer = new byte[requestSize + INT_SIZE];
		ObjectOutput ss = new SerializeStream(buffer);
		ss.writeInt(requestSize);
		ss.writeObject(request);
		return buffer;
	}


	private ByteBuffer bbSerialize(Object request, ByteBuffer poolBuffer) throws IOException {
		int requestSize = calculateSize(request);
		ByteBuffer buffer = getBuffer(requestSize + INT_SIZE, poolBuffer);        
		write(request, requestSize, buffer);
		return buffer;
	}

	private void write(Object request, int requestSize, ByteBuffer buffer)
			throws IOException {
		ObjectOutput ss = new BBSerializeStream(buffer);
		ss.writeInt(requestSize);
		ss.writeObject(request);
	}

	private int calculateSize(Object request) throws IOException {
		CalcSizeStream calcSizeStream = new CalcSizeStream();
		calcSizeStream.writeObject(request);
		return calcSizeStream.count();
	}

	private ByteBuffer getBuffer(int size, ByteBuffer poolBuffer) {
		if (size <= poolBuffer.capacity()) {
			return poolBuffer;
		}
		return ByteBuffer.allocate(size);
	}

	private void sendRequest(Socket socket, byte[] buffer) throws IOException {
		socket.writeFully(buffer, 0, buffer.length);
		socket.readFully(buffer, 0, 4);
	}

	private void sendRequest(Socket socket, ByteBuffer buffer) throws IOException {
		buffer.flip();
		socket.write(buffer);
	}

	private byte[] readResponse(Socket socket, byte[] buffer) throws IOException {
		if (buffer[0] != 0) {
			throw new IOException("Invalid response header or response too large");
		}

		int responseSize = (buffer[1] & 0xff) << 16 | (buffer[2] & 0xff) << 8 | (buffer[3] & 0xff);
		if (responseSize > 4) {
			buffer = new byte[responseSize];
		}

		socket.readFully(buffer, 0, responseSize);
		return buffer;
	}

	private ByteBuffer readResponse(Socket socket, ByteBuffer buffer) throws IOException {
		int responseSize = readSize(socket);
		//        (sizeBuf.get(1) & 0xff) << 16 | (sizeBuf.get(2) & 0xff) << 8 | (sizeBuf.get(3) & 0xff);

		if (buffer != null && buffer.isDirect() && buffer.capacity() >= responseSize) {
			buffer.clear();
		} else {
			if (buffer != null && buffer.isDirect()) {
				DirectByteBufferPool.returnBuffer(buffer);
			}

			if (responseSize < DirectByteBufferPool.BUFFER_SIZE) {
				try {
					buffer = DirectByteBufferPool.leaseBuffer();
				} catch (Exception e) {
					e.printStackTrace();
					System.err.println ("RpcSession: Can't get DBB. Allocationg on-heap buffer");
					buffer = ByteBuffer.allocate(DirectByteBufferPool.BUFFER_SIZE);
				}
			} else {	        	
				buffer = ByteBuffer.allocate(responseSize);
			}
		}

		socket.read(buffer);
		return buffer;
	}

	private int readSize(Socket socket) throws IOException {
		ByteBuffer sizeBuf = ByteBuffer.allocate(4);
		socket.read(sizeBuf);
		if (sizeBuf.get(0) != 0) {
			throw new IOException("Invalid response header or response too large");
		}

		int responseSize = sizeBuf.asIntBuffer().get();
		return responseSize;
	}
}
