package one.nio.buffers;

import java.nio.ByteBuffer;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class DirectByteBufferPool {
    public static final int BUFFER_SIZE = 8000;
    public static final int MAX_POOL_SIZE = 100;
    
    private static BlockingQueue<ByteBuffer> queue = null;
        
	public synchronized static ByteBuffer leaseBuffer() {
		if (queue == null) {
			queue = new ArrayBlockingQueue<ByteBuffer>(MAX_POOL_SIZE);
			while (queue.size() < MAX_POOL_SIZE) {
				queue.add(ByteBuffer.allocateDirect(BUFFER_SIZE)); //TODO: parameter!
			}
		}
		
		ByteBuffer bb = queue.poll();
		bb.clear();
		return bb;
	}
	
	public synchronized static void returnBuffer(ByteBuffer bb) {
		assert bb.capacity() == BUFFER_SIZE;
		if (queue.size() < MAX_POOL_SIZE) {
			queue.add(bb);
		}
	}
}
