package one.nio.util;

import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.nio.ByteBuffer;

public class ByteBufferStream implements ObjectInput, ObjectOutput {
    protected ByteBuffer buf;
    protected int count;

    public ByteBufferStream(ByteBuffer buf) {
    	this.buf = buf;//.duplicate();    	
    	this.count = 0;
    }
    
    public ByteBufferStream(int capacity, boolean isDirect) {
    	if (isDirect) {
    		this.buf = ByteBuffer.allocateDirect(capacity);
    	} else { 
    		this.buf = ByteBuffer.allocate(capacity);
    	}
        
        this.count = 0;
    }

    public int count() {
        return count;
    }

    public void write(int b) {
    	buf.put((byte) b);
        count++;
    }

    public void write(byte[] b) {
        System.arraycopy(b, 0, buf, count, b.length);
        count += b.length;
    }

    public void write(byte[] b, int off, int len) {
        System.arraycopy(b, off, buf, count, len);
        count += len;
    }

    public void writeBoolean(boolean v) {
    	buf.put(v ? (byte) 1 : (byte) 0);
        count++;
    }

    public void writeByte(int v) {
    	buf.put((byte)v);
        count++;
    }

    public void writeShort(int v) {
    	buf.put((byte) (v >>> 8));
        count++;
        buf.put((byte) v);
        count++;
    }

    public void writeChar(int v) {
    	buf.put((byte) (v >>> 8));
        count++;
        buf.put((byte) v);
        count++;
    }

    public void writeInt(int v) {
    	buf.put((byte) (v >>> 24));
        count++;
        buf.put((byte) (v >>> 16));
        count++;
    	buf.put((byte) (v >>> 8));
        count++;
        buf.put((byte) v);
        count++;
    }

    public void writeLong(long v) {
    	buf.put((byte) (v >>> 56));
        count++;
        buf.put((byte) (v >>> 48));
        count++;
    	buf.put((byte) (v >>> 40));
        count++;
        buf.put((byte) (v >>> 32));
        count++;
        buf.put((byte) (v >>> 24));
        count++;
        buf.put((byte) (v >>> 16));
        count++;
    	buf.put((byte) (v >>> 8));
        count++;
        buf.put((byte) v);
        count++;
    }

    public void writeFloat(float v) {
        writeInt(Float.floatToRawIntBits(v));
    }

    public void writeDouble(double v) {
        writeLong(Double.doubleToRawLongBits(v));
    }

    public void writeBytes(String s) {
        int length = s.length();
        buf.put(s.getBytes());
        count += length;
    }

    public void writeChars(String s) {
        int length = s.length();
        for (int i = 0; i < length; i++) {
            int v = s.charAt(i);
        	buf.put((byte) (v >>> 8));
            count++;
            buf.put((byte) v);
            count++;
        }
    }
    
    public void writeUTF(String s) {
        int utfLength = Utf8.simulateWrite(s); 
        if (utfLength <= 0x7fff) {
            writeShort(utfLength);
        } else {
            writeInt(utfLength | 0x80000000);
        }
        Utf8.write(s, buf);
        count += utfLength;
    }

    public void writeObject(Object obj) throws IOException {
        throw new UnsupportedOperationException();
    }

    public int read() {
        return buf.get(count++);
    }

    public int read(byte[] b) {
        readFully(b);
        return b.length;
    }

    public int read(byte[] b, int off, int len) {
        readFully(b, off, len);
        return len;
    }

    public void readFully(byte[] b) {
        System.arraycopy(buf, count, b, 0, b.length);
        count += b.length;
    }

    public void readFully(byte[] b, int off, int len) {
        System.arraycopy(buf, count, b, off, len);
        count += len;
    }

    public long skip(long n) throws IOException {
        count += n;
        return n;
    }

    public int skipBytes(int n) {
        count += n;
        return n;
    }

    public boolean readBoolean() {
        return buf.get(count++) != 0;
    }

    public byte readByte() {
        return buf.get(count++);
    }

    public int readUnsignedByte() {
        return buf.get(count++) & 0xff;
    }

    public short readShort() {
        short result = (short) (buf.get(count) << 8 | (buf.get(count + 1) & 0xff));
        count += 2;
        return result;
    }

    public int readUnsignedShort() {
        int result = (buf.get(count) & 0xff) << 8 | (buf.get(count + 1) & 0xff);
        count += 2;
        return result;
    }

    public char readChar() {
        char result = (char) (buf.get(count) << 8 | (buf.get(count + 1) & 0xff));
        count += 2;
        return result;
    }

    public int readInt() {
        int result = buf.get(count) << 24 |
                     (buf.get(count + 1) & 0xff) << 16 |
                     (buf.get(count + 2) & 0xff) <<  8 |
                     (buf.get(count + 3) & 0xff);
        count += 4;
        return result;
    }

    public long readLong() {
        long result = (long) buf.get(count) << 56 |
                      (buf.get(count + 1) & 0xffL) << 48 |
                      (buf.get(count + 2) & 0xffL) << 40 |
                      (buf.get(count + 3) & 0xffL) << 32 |
                      (buf.get(count + 4) & 0xffL) << 24 |
                      (buf.get(count + 5) & 0xffL) << 16 |
                      (buf.get(count + 6) & 0xffL) <<  8 |
                      (buf.get(count + 7) & 0xffL);
        count += 8;
        return result;
    }

    public float readFloat() {
        return Float.intBitsToFloat(readInt());
    }

    public double readDouble() {
        return Double.longBitsToDouble(readLong());
    }

    public String readLine() {
        if (count < buf.capacity()) {
            StringBuilder sb = new StringBuilder();
            do {
                byte b = buf.get(count++);
                if (b == 10) {
                    break;
                } else if (b != 13) {
                    sb.append((char) b);
                }
            } while (count < buf.capacity());
            return sb.toString();
        } else {
            return null;
        }
    }

    public String readUTF() {
        int length = readUnsignedShort();
        if (length == 0) {
            return "";
        }
        if (length > 0x7fff) {
            length = (length & 0x7fff) << 16 | readUnsignedShort();
        }
        String result = Utf8.read(buf, count, length);
        count += length;
        return result;
    }

    public Object readObject() throws IOException, ClassNotFoundException {
        throw new UnsupportedOperationException();
    }

    public int available() {
        return buf.capacity() - count;
    }

    public void flush() {
        // Nothing to do
    }

    public void close() {
        // Nothing to do
    }
}
